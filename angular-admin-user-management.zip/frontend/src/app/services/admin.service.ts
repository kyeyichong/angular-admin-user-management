import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { OrganizationModel, AdminUser } from '../models/admin.model';
import { PersonListModel, PersonDetailModel } from '../models/personal.model';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http: HttpClient) { }

  public getOrganizationList() {
    const serverUrl = `${environment.apiURL}orgs/`;
    return this.http.get<OrganizationModel[]>(serverUrl);
  }

  public addOrganization(addName: string) {
    const serverUrl = `${environment.apiURL}orgs/`;
    return this.http.post<string>(serverUrl, { name: addName });
  }

  public renameOrganization(orgId: number, addName: string) {
    const serverUrl = `${environment.apiURL}orgs/${orgId}`;
    return this.http.post(serverUrl, { name: addName });
  }

  public deleteOrganization(orgId: number) {
    const serverUrl = `${environment.apiURL}orgs/${orgId}`;
    return this.http.delete<string>(serverUrl);
  }

  public getUsersList(): Observable<PersonDetailModel[]> {
    const serverUrl = `${environment.apiURL}admin/usersmanage/`;
    return this.http.get<PersonDetailModel[]>(serverUrl);
  }

    public getAllUsersList(): Observable<PersonDetailModel[]> {
        const serverUrl = `${environment.apiURL}users/`;
        return this.http.get<PersonDetailModel[]>(serverUrl);
    }

  public addUser(userInfo: PersonDetailModel) {
    // const serverUrl = `assets/user.json`;
    console.log(userInfo);
    const serverUrl = `${environment.apiURL}admin/usersmanage/`;
    return this.http.post(serverUrl, userInfo);
  }

  public updateUser(userInfo: PersonListModel) {
    console.log('******start*******');
    console.log(userInfo);
    console.log('******start*******');
    // const serverUrl = `assets/user.json`;
    const serverUrl = `${environment.apiURL}users/${userInfo.postid}`;
    return this.http.post(serverUrl, userInfo);
  }

  public deleteUser(postId) {
    const serverUrl = `${environment.apiURL}users/${postId}`;
    return this.http.delete<PersonListModel>(serverUrl);
  }

  uploadImage(postid, file: File) {
    const serverUrl = `${environment.apiURL}users/${postid}`;
    const formData = new FormData();
    formData.append('image', file);
    return this.http.put(serverUrl, formData);
  }

  uploadCSV(fileToUpload: File): Observable<any> {
    const serverUrl = `${environment.apiURL}csv/`;
    const formData: FormData = new FormData();
    formData.append('file', fileToUpload, fileToUpload.name);
    return this.http.post<any>(serverUrl, formData);
  }

  updateAdminPassword(oldpwd: string, newpwd: string) {
    const serverUrl = `${environment.apiURL}admin/`;
    return this.http.post(serverUrl, { old: oldpwd, new: newpwd });
  }

  public loadUserList(): Observable<any> {
    const serverUrl = `${environment.apiURL}admin/users/`;
    return this.http.get<AdminUser[]>(serverUrl);
  }

  public updateAdminUser(userData: AdminUser): Observable<any> {
    const serverUrl = `${environment.apiURL}admin/users/` + userData.id + '/';
    return this.http.post(serverUrl, userData);
  }

  public deleteAdminUser(userData: AdminUser): Observable<any> {
    const serverUrl = `${environment.apiURL}admin/users/` + userData.id + '/';
    return this.http.delete(serverUrl);
  }
}
