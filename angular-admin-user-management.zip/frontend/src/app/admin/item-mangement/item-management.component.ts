import { Component, OnInit, ViewChild } from '@angular/core';


@Component({
  selector: 'app-items',
  templateUrl: './item-management.component.html',
  styles: [``]
})
export class ItemsMangementComponent implements OnInit {
  ngOnInit(): void {
  }
}

