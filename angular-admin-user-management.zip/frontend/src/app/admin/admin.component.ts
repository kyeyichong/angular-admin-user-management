import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit, OnDestroy {


  mobileQuery: MediaQueryList;

  sideBar = [
    { url: '/admin/dashboard', label: 'Dashboard', role: 'editor' },
    { url: '/admin/contributors', label: 'Contributors', role: 'editor' },
    { url: '/admin/items', label: 'Items', role: 'editor' },
    { url: '/admin/users', label: 'User Management', role: 'admin' },
    { url: '/admin/security', label: 'Security', role: 'editor' },
  ];


  private mobileQueryListener: () => void;

  constructor(changeDetectorRef: ChangeDetectorRef, media: MediaMatcher, private authService: AuthService) {
    this.mobileQuery = media.matchMedia('(max-width: 1024px)');
    this.mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addEventListener('change', this.mobileQueryListener);
  }

  ngOnInit() { }

  ngOnDestroy() {
    this.mobileQuery.removeEventListener('change', this.mobileQueryListener);
  }
  getCheckUserRole(side) {
    switch (this.authService.currentUserValue.role) {
      case 'admin':
        return true;
      case 'editor':
        switch (side.role) {
          case 'editor':
            return true;
          default:
            return false;
        }
      default:
        return false;
    }
  }
}
