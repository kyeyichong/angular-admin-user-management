import { Component, OnInit } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';
import { AdminUser } from 'src/app/models/admin.model';

interface Alert {
  type: string;
  message: string;
}

@Component({
  selector: 'app-admin-user-manage',
  templateUrl: './admin-user-manage.component.html',
  styleUrls: ['./admin-user-manage.component.scss']
})
export class AdminUserManageComponent implements OnInit {

  public userlist: AdminUser[];
  public msgAlert = {
    type: '',
    message: '',
  };

  public USER_ROLE = [
    { label: 'Admin', value: 'admin' },
    { label: 'Editor', value: 'editor' },
    { label: 'Not Allowed', value: 'notallowed' },
  ];

  constructor(private admin: AdminService) { }

  ngOnInit() {
    this.loadUserList();
  }

  private loadUserList() {
    this.admin.loadUserList().subscribe((res: AdminUser[]) => {
      this.userlist = res;
    }, (err) => {
      this.msgAlert.type = 'danger';
      this.msgAlert.message = err;
    });
  }

  public updateUserInformation(user: AdminUser) {
    this.admin.updateAdminUser(user).subscribe((res) => {
      this.msgAlert.type = 'info';
      this.msgAlert.message = 'Success';
    }, err => {
      this.msgAlert.type = 'danger';
      this.msgAlert.message = err;
    });

  }

  public deleteUserInformation(user: AdminUser) {
    this.admin.deleteAdminUser(user).subscribe((res) => {
      this.msgAlert.type = 'info';
      this.msgAlert.message = 'Success';
    }, err => {
      this.msgAlert.type = 'danger';
      this.msgAlert.message = err;
    });
  }
  closeAlert(alert: Alert) {
    this.msgAlert.message = '';
  }
}
