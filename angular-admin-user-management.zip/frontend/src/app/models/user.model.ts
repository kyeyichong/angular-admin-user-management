export class User {
  id: string;
  email: string;
  username: string;
  password: string;
  token?: string;
  role: string;
}
